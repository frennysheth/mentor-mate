# mentor-mate
Mentor mate is an online mentoring website based on PHP
where the student and faculties from their own respective universities/colleges or schools can interact freely and solve their queries.

Hey there as this was my first ever project one may find this code not upto point and i totally agree
so feel free to make changes and let me know if there is something to improve in this porject. 
I'm open for new ideas.

Things to keep in mind before using these files:
   Make sure the database that you are using gave same names for the tables and columns or you can 
   use the provided database  

Have Fun!!!
