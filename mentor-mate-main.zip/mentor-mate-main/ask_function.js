function insert_successfull_alert(){
    alert('Question Posted Successfully');  
}